//our root app component
import {Component, NgModule, Input} from '@angular/core'
import {BrowserModule} from '@angular/platform-browser'


export class Quote{
  
  name:string;
  quoteline:string;
  hide:boolean;
  
  constructor(name:string,quoteline:string) {
      this.name = name;
      this.quoteline = quoteline;
      this.hide = true;
  }
  
  toggle(){
    this.hide=!this.hide;
  }
}

@Component({
  selector:'app',
  template: `
      <QuotesList> </QuotesList>
  `,
})
export class AppComponent{
  
}


@Component({
  selector: 'QuotesList',
  template : `  
          <Quote *ngFor = "let j of Quotes" [quote]="j"></Quote>
      `,
})
  export class QuotesList {
    Quotes:Quote[];
      
      constructor(){
            this.Quotes = [new Quote("Name1","Quote1"), new Quote("Name2","Quote2"), new Quote("Name3","Quote3")];      
          }
      }

@Component({
  selector: 'Quote',
  template: `
        <div class="rootComponent">
          <h4>{{data.name}}</h4>
          <p [hidden]="data.hide">{{data.quoteline}}</p>
          <button type="submit" value="Submit" (click)="data.toggle()">tell me</button>
        </div>

  `,
})
export class QuoteComponent {
  // tels angular it is input property, so bound to it as public interface
  // so we need to pass from QuoteList component, it is exposed there
  //@Input() quote:Quote;
  // data to generalize it
    @Input('quote') data:Quote;
}


@NgModule({
  imports: [ BrowserModule ],
  declarations: [QuotesList, QuoteComponent, AppComponent],
  bootstrap: [ AppComponent ]
})
export class AppModule {}